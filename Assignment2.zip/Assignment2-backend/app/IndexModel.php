<?php
use FD\framework\Observable_Model;

class IndexModel extends Observable_Model
{
	use FD\framework\Insert_Trait;

	public function findAll() : array
	{
		$conn = $this->makeConnection();

		$recquery = "SELECT * FROM courses ORDER BY course_recommendation_count DESC";
		$popquery = "SELECT * FROM courses ORDER BY course_access_count DESC";

		$recquerydata =  mysqli_query($conn,$recquery);
		$popquerydata = mysqli_query($conn, $popquery);

		$reccolumn = mysqli_fetch_array($recquerydata);
		$popcolumn = mysqli_fetch_array($popquerydata);

		//to do query to get instructor

		$recfulldata = array(array($reccolumn["course_name"]),array($reccolumn["course_image"]));
		$popfulldata = array(array($popcolumn["course_name"]),array($popcolumn["course_image"]));
		$rec = array_slice($recfulldata, 0, 8);
		$pop = array_slice($popfulldata, 0, 8);
		mysqli_close($conn);
		return ['recommended'=>$rec, 'popular'=>$pop];
	}

	public function findRecord(string $id) : array
	{
		return [];
		/*$singledata - $this->LoadData(ddir . '/.json');

		if(empty($id))
		{
			trigger_error("No Identifier was specified", E_USER_ERROR);
		}

		else
		{

		}*/
	}

	public function insert(array $values)
	{

	}
}

?>