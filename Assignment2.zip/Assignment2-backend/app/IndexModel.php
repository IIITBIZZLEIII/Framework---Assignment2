<?php
use FD\framework\Observable_Model

class IndexModel extends Observable_Model
{
	use FD\framework\Insert_Trait;

	public function findAll() : array
	{
		$idata = $this->LoadData(ddir . '/courses.json');

		$popcolumn = array_column($idata['courses'], 3);
		$reccolumn = array_column($idata['courses'], 2);
		$arraycopy = $idata['courses'];

		array_multisort($reccolumn, SORT_DESC, $idata['courses']);
		$rec = array_slice($idata['courses'], 0, 8);

		array_multisort($popcolumn, SORT_DESC, $arraycopy);
		$pop = array_slice($arraycopy, 0, 8);

		return ['recommended'=>$rec, 'popular'=>$pop];
	}

	public function findRecord(string $id) : array
	{
		return [];
		/*$singledata - $this->LoadData(ddir . '/.json');

		if(empty($id))
		{
			trigger_error("No Identifier was specified", E_USER_ERROR);
		}

		else
		{

		}*/
	}

	public function insert(array $values)
	{

	}
}

?>