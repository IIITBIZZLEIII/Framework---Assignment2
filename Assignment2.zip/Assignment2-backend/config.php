<?php

const rootdir = 'c:/xampp2/Assignment2-backend';
const tempdir = rootdir . '/tpl';
const ddir = rootdir . '/data';

?>