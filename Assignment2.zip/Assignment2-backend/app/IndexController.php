<?php
namespace Apps\handlers;
use FD\framework\CommandContext;
use FD\framework\PageController_Command_Abstract;
use FD\framework\View;

class IndexController extends PageController_Command_Abstract
{
	private $data = null;
	public function run()
	{
		$iview = new View();
		$iview->setTemplate(tempdir . '/index.tpl.php');
		$this->setView ($iview);
		$this->setModel(new \IndexModel());
		$this->model->attach($this->view);

		$idata = $this->model->findAll();

		$this->model->Updatedata($idata);

		$this->model->notify();
	}

	public function execute(CommandContext $context) : bool
	{
		$this->data = $context;
		$this->run();
		return true;
	}
}

?>