<?php
namespace FD\framework;

trait Insert_Trait
{
	abstract public function insert(array $values);
}