<?php
namespace FD\framework;

class FrontController extends FrontController_Abstract
{

	public static function run()
	{
		$FController = new FrontController();
		$FController->init();
		$FController->HandleRequest();
	}

	protected function init()
	{

	}

	protected function HandleRequest()
	{
		$context = new CommandContext();
		$getrequest = $context->get('get');
		//var_dump($request);

		if(!empty($get))
		{
			$request = $getrequest['controller'];
			$handler = RequestHandlerFactory::makeRequestHandler($request);
		}
		else
		{
			$handler = RequestHandlerFactory::makeRequestHandler();		
		
		}
		if($handler->execute($context)===false)
		{

		}
	}
}

?>
