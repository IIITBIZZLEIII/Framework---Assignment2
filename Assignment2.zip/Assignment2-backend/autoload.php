<?php
spl_autoload_register(function($class)
{
	$arr = explode('\\',$class);
	$classname = $arr[count($arr)-1];
	if (!defined('APP_DIR'))
	{
		define("ROOT_DIR", 'C:/xampp2/Assignment2-backend');
		define("APP_DIR", ROOT_DIR . '\app');
		define("FRAMEWORK_DIR", ROOT_DIR . '\framework');
		define("TPL_DIR", ROOT_DIR . '\tpl');
		define("DATA_DIR", ROOT_DIR . '\data');
	}
	if(file_exists(FRAMEWORK_DIR."/". $classname .'.php'))
	{
		require FRAMEWORK_DIR."/". $classname .'.php';
	}	
	elseif(file_exists(APP_DIR."/". $classname .'.php'))
	{
		require APP_DIR."/". $classname .'.php';
	}
	elseif(file_exists(TPL_DIR."/". $classname .'.php'))
	{
		require TPL_DIR."/". $classname .'.php';
	}
	elseif(file_exists(DATA_DIR."/". $classname .'.php'))
	{
		require DATA_DIR."/". $classname .'.php';
	}/*
	else
	{
		trigger_error('Unable to find Class/Interface/Abstract class: ' . $class, E_USER_ERROR);
		debug_backtrace();
	}*/
});