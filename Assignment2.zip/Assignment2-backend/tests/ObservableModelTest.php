<?php

require_once "framework/Observable_Model.php";

use PHPUnit\Framework\TestCase;

class ObservableModelTest extends TestCase 
{
	public function modelObjectCreatedTest()
	{
		$this->assertIsObject(new Observable_Model);
	}

	public function checkObserverableDetachTest()
	{
		/*$model = new Observable_Model();
		$view = new View();

		$model->attach($view);
		$this->assertIsObject($model->getobservers());*/
	}

	public function testObserverableAttachTest()
	{
		/*$model = new Observable_Model();
		$view = new View();

		$atcview = $model->attach($view);
		$this->assertIsObject($model->getobservers());

		$reflec = new ReflectionFunction('atcview');
		$rtype = $reflec->getReturnType();
		$this->assertIsarray($rtype);*/

	}

	/*public function getAllRecordsTest()
	{
		$model = new Observable_Model();
		$records = $model->getAll();
		$this->assertCount(1, $records[0]);
	}

	public function getRecordTest()
	{
		$model2 = new Observable_Model();
		$record = $model2->getRecord();
		$this->
	}*/
}