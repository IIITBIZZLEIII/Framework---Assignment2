<?php
namespace FD\framework;

abstract class FrontController_Abstract
{
	protected $requestHandler = null;

	abstract public static function run();

	abstract protected function init();

	abstract protected function HandleRequest();
}

?>