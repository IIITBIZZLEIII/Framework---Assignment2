<?php

interface Observable_interface
{
	public function attach(Observer_interface $o);

	public function detach(Observer_interface $o);

	public function notify();
}

?>