<?php
namespace FD\framework;

class FrontController extends FrontController_Abstract
{

	public static function run()
	{
		$FController = new FrontController();
		$FController->init();
		$FController->HandleRequest();
	}

	protected function init()
	{

	}

	protected function HandleRequest()
	{
		$context = new CommandContext();
		$request = (string) $context->get('request');
		var_dump($request);
		$handler = RequestHandlerFactory::makeRequestHandler($request);		
		$handler->execute($context);
	}
}

?>
