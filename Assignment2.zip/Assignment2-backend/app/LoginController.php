<?php

class LoginController extends PageController_Abstract
{
	protected function makeView() : View
	{
		$view = new View();
		$view->setTemplate(tempdir . '/login.tpl.php');
		return $view;
	}

	public function run()
	{
		if(isset($_POST['signin']))
		{
			$validation = new ValidateController();
			if($validation->run() == true)
			{
				echo "validate working";
				SessionManager::create();
				$SManager = new SessionManager();
				//var_dump($_POST);
				$SManager->add('user',$_POST['uzrEmail']);
				/*$PController = new ProfileController();
				$PController->run();*/
				header('Location:index.php?controller=Profile');
			}
			else
			{
				echo "error occured during validation";
				unset($_POST);
				$this->setView = $this->makeView();
				$this->setView->display();
			}
		}
		else
		{
			unset($_POST);
			$this->setView = $this->makeView();
			$this->setView->display();
		}
	}
}

?>